#Instrucciones
    .Pagina web maqueta de un distribuidor de verduras
    .Contiene catalogo de verduras
    .Contiene formulario de contacto
#Informacion del coder
    .(Nombre): Lucas Daniel Chacon Reyes
    .(Clan): Sierra
    .(Correo): lucasdanielchaconr@gmail.com
